//
//  TestModel.swift
//  UnitTests
//
//  Created by Jak Tiano on 10/23/16.
//  Copyright © 2016 PacktPub. All rights reserved.
//

import Foundation

class TestModel {
    
    func example1() -> Int {
        return 1
    }
    
    func example2() -> Int {
        return 2
    }
    
    func example3() -> Int {
        return 3
    }
    
}
